//
//  ChatMessage.m
//  ChatMessageProject
//
//  Created by Mahwish Munir on 8/11/16.
//  Copyright (c) 2016 Mahwish Munir. All rights reserved.
//

#import "ChatMessage.h"

@implementation ChatMessage


-(NSString *)chatJSONString:(NSString *)searchedString
{
    self.mentionArray =[[NSMutableArray alloc] init];
    self.emoticonsArray =[[NSMutableArray alloc] init];
    self.linksArray =[[NSMutableArray alloc] init];
    self.linksDictionary = [[NSMutableDictionary alloc] init];
    self.resultDictionary = [[NSMutableDictionary alloc] init];
    
    if ([searchedString rangeOfString:@"@"].location != NSNotFound)
    {
        pattern = @"\\B@\\S*";
        matches = [self searchForPattern:searchedString strPattern:pattern];
        
        for (NSTextCheckingResult* match in matches) {
            NSString* matchText = [searchedString substringWithRange:[match range]];
           // NSLog(@"match text %@",matchText);
            
            NSString *mentionString = [matchText substringFromIndex:1];
            [self.mentionArray addObject:mentionString];
           // NSLog(@"Mention %@ ",mentionString);
        }

        
    }
    if ([searchedString rangeOfString:@"("].location != NSNotFound)
    {
        pattern = @"\\(.*?\\)";
        matches = [self searchForPattern:searchedString strPattern:pattern];
        
        for (NSTextCheckingResult* match in matches) {
            NSString* matchText = [searchedString substringWithRange:[match range]];
           // NSLog(@"match text %@",matchText);
            
            NSString *newStr = [matchText substringFromIndex:1];
            NSString *emoticonString =[newStr substringToIndex:[newStr length]-1];
            
            if ([emoticonString length]<=15) {
                
                [self.emoticonsArray addObject:emoticonString];
            }
           // NSLog(@"Emoticon %@ ",emoticonString);
        }
    }
    if ([searchedString rangeOfString:@"https"].location != NSNotFound ||
        [searchedString rangeOfString:@"http"].location != NSNotFound)
    {
        pattern = @"(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+";
        matches = [self searchForPattern:searchedString strPattern:pattern];
        
        for (NSTextCheckingResult* match in matches) {
            NSString* matchText = [searchedString substringWithRange:[match range]];
            //NSLog(@"match text %@",matchText);
            
            [self.linksDictionary setObject:matchText forKey:@"url"];
            NSString *title = [self getUrlTitle:matchText];
            [self.linksDictionary setObject:title forKey:@"title"];
            [self.linksArray addObject:self.linksDictionary];
        }
    }
    if ([self.mentionArray count] >0) {
        
        [self.resultDictionary setObject:self.mentionArray forKey:@"mentions"];
    }
    if ([self.emoticonsArray count]>0) {
        [self.resultDictionary setObject:self.emoticonsArray forKey:@"emoticons"];
    }
    if ([self.linksArray count] >0) {
        [self.resultDictionary setObject:self.linksArray forKey:@"links"];
    }
//    NSLog(@"NameArray %@ ,EmoticonsArray %@ ,LinkArray %@,link dictionary %@",self.mentionArray,self.emoticonsArray,self.linksArray,self.linksDictionary);
    NSString *JsonString = [self dictionaryToJSONString:self.resultDictionary];
   // NSLog(@"dictionary %@ ,JSONString %@",self.resultDictionary,JsonString);
    
    return JsonString;
    
}

-(NSString *)dictionaryToJSONString :(NSMutableDictionary *)resultDictionary
{
    NSString *jsonString;
    NSError *error;
    // Pass 0 in options, if you don't care about the readability of the generated string
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:resultDictionary
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    if (! jsonData){
        NSLog(@"Got an error: %@", error);
    }
    else{
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    return jsonString;
}



-(NSString *)getUrlTitle:(NSString *)url
{
    NSString * htmlCode = [NSString stringWithContentsOfURL:[NSURL URLWithString:url]
                                                   encoding:NSASCIIStringEncoding error:nil];
    
    NSString * startTag = @"<title>";
    NSRange startRange = [htmlCode rangeOfString:startTag];
    
    NSString * endTag = @"</title>";
    NSRange endRange = [htmlCode rangeOfString:endTag];
    //I Used +7 and -7 in NSMakeRange to eliminate the length of <title> i.e 7
    NSString * subString = [htmlCode substringWithRange:NSMakeRange(startRange.location + 7,
                                                                    endRange.location - startRange.location - 7)];
   // NSLog(@"substring is %@",subString);
    return subString;
    
}

-(NSArray *)searchForPattern:(NSString *)searchedString strPattern:(NSString *)stringPattern
{
    NSRange  searchedRange = NSMakeRange(0, [searchedString length]);
    NSError  *error = nil;
    NSRegularExpression* regex = [NSRegularExpression regularExpressionWithPattern:stringPattern options:0 error:&error];
    NSArray *matchesArray = [regex matchesInString:searchedString options:0 range: searchedRange];
    return matchesArray;
}

@end
