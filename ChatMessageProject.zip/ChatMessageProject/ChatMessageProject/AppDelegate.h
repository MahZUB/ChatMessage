//
//  AppDelegate.h
//  ChatMessageProject
//
//  Created by Mahwish Munir on 8/11/16.
//  Copyright (c) 2016 Mahwish Munir. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

