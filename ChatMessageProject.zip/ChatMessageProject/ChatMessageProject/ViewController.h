//
//  ViewController.h
//  ChatMessageProject
//
//  Created by Mahwish Munir on 8/11/16.
//  Copyright (c) 2016 Mahwish Munir. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end

