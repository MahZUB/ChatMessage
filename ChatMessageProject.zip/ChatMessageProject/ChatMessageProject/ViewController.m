//
//  ViewController.m
//  ChatMessageProject
//
//  Created by Mahwish Munir on 8/11/16.
//  Copyright (c) 2016 Mahwish Munir. All rights reserved.
//

#import "ViewController.h"
#import "ChatMessage.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

   // NSString *inputString = @"@chris you around?";
   // NSString *inputString = @"Good morning! (megusta) (coffee)";
   // NSString *inputString = @"Olympics are starting soon;http://www.nbcolympics.com";
       NSString *inputString = @"@bob @john (success) such a cool feature; http://www.nbcolympics.com";
    
    ChatMessage *chatMessage = [[ChatMessage alloc] init];
    NSString *result = [chatMessage chatJSONString:inputString];
    NSLog(@"Result %@",result);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
