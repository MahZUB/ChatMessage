//
//  ChatMessage.h
//  ChatMessageProject
//
//  Created by Mahwish Munir on 8/11/16.
//  Copyright (c) 2016 Mahwish Munir. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ChatMessage : NSObject
{
    NSArray  *matches;
    NSString *pattern;
}

@property(nonatomic,strong) NSMutableDictionary *linksDictionary;
@property(nonatomic,strong) NSMutableDictionary *resultDictionary;
@property(nonatomic,strong) NSMutableArray *mentionArray;
@property(nonatomic,strong) NSMutableArray *emoticonsArray;
@property(nonatomic,strong) NSMutableArray *linksArray;


-(NSString *)chatJSONString:(NSString *)searchedString;
-(NSString *)getUrlTitle:(NSString *)url;
-(NSArray *)searchForPattern:(NSString *)searchedString strPattern:(NSString *)stringPattern;
@end
